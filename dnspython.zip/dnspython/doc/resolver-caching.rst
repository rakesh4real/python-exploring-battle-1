.. _resolver-caching:

Resolver Caching Classes
========================

This is a placeholder.

.. autoclass:: dns.resolver.Cache
   :members:

.. autoclass:: dns.resolver.LRUCache
   :members:

