.. _rdata-make:

Making DNS Rdata
----------------

.. autofunction:: dns.rdata.from_text
.. autofunction:: dns.rdata.from_wire
