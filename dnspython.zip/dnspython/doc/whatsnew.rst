.. _whatsnew:

What's New in dnspython 1.16.0
==============================

New Features
------------

Bug Fixes
---------

