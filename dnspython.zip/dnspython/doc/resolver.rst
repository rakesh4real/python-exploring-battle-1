.. module:: dns.resolver
.. _resolver:

Stub Resolver
=============

This is a placeholder.

.. toctree::

   resolver-class
   resolver-functions
   resolver-caching
   resolver-override
