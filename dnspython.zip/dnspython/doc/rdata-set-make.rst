.. _rdata-make:

Making DNS Rdatasets and RRsets
===============================

.. autofunction:: dns.rdataset.from_text
.. autofunction:: dns.rdataset.from_text_list
.. autofunction:: dns.rdataset.from_rdata
.. autofunction:: dns.rdataset.from_rdata_list
.. autofunction:: dns.rrset.from_text
.. autofunction:: dns.rrset.from_text_list
.. autofunction:: dns.rrset.from_rdata
.. autofunction:: dns.rrset.from_rdata_list
