.. _message-update:

The dns.update.Update Class
---------------------------

DNS Dynamic Update message have a complex encoding, so
dnspython provides a subclass of ``dns.message.Message``
specialized for creating them.

.. autoclass:: dns.update.Update
   :members:
