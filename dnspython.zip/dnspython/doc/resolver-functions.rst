.. _resolver-functions:

Resolver Functions and The Default Resolver
===========================================

.. autofunction:: dns.resolver.query
.. autofunction:: dns.resolver.zone_for_name
.. autodata:: dns.resolver.default_resolver
.. autofunction:: dns.resolver.get_default_resolver
.. autofunction:: dns.resolver.reset_default_resolver
